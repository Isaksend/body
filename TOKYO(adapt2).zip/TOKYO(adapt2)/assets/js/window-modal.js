let openModalButton = document.getElementById("openModalButton");
let modalContainer = document.getElementById("myModal");
let closeModalButton = document.querySelector(".close-button");

openModalButton.addEventListener("click", function () {
    modalContainer.style.display = "block";
});

closeModalButton.addEventListener("click", function () {
    modalContainer.style.display = "none";
});

window.addEventListener("click", function (event) {
    if (event.target === modalContainer) {
        modalContainer.style.display = "none";
    }
});