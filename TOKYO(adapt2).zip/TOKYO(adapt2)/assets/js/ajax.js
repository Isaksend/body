
$(document).ready(function (){
    $('#btn').on('click', function (){
        let message = document.getElementById('comment').value;
        let username = document.getElementById('username').value;
        let phone = document.getElementById('phone').value;

        $.ajax({
            method: "POST",
            url: "../../../php/reports/send.php",
            data: { "message": message, "phone": phone, "username": username }
        }).done(function (res){
            let date = JSON.parse(res);
            document.getElementById('contact-form').style.display = 'none';

            switch (date.status){
                case 'ok':
                    document.getElementById('msg').innerHTML =
                        '<div class="space-50"><div class="modal-description text-center">' +
                        'Спасибо! Мы в скором времени свяжемся с вами</div><div>';
                    break;
                case 'error':
                    document.getElementById('msg').innerHTML =
                        '<div class="space-50"><div class="modal-description text-center">' +
                        '</div>'+ date.message +'<div>';
                    break;
            }
        })
    })
});