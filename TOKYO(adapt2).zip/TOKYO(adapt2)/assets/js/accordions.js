let accordionItems = document.querySelectorAll('.accordion-item');

accordionItems.forEach(function (item) {
    let accordionLink = item.querySelector('.accordion-link');
    let accordionArrow = item.querySelector('.arrow-down path');
    let accordionAnswer = item.querySelector('.answer');

    accordionLink.addEventListener('click', function (e) {
        e.preventDefault();

        if (item.classList.contains('open')) {
            item.classList.remove('open');

            if (accordionArrow !== null)
                accordionArrow.setAttribute('fill', '#FFFFFF');

            accordionAnswer.style.maxHeight = '0';
        } else {
            accordionItems.forEach(function (otherItem) {
                let otherArrow = otherItem.querySelector('.arrow-down path');

                if (otherArrow !== null)
                    otherArrow.setAttribute('fill', '#FFFFFF');

                otherItem.classList.remove('open');

                let otherAnswer = otherItem.querySelector('.answer');
                otherAnswer.style.maxHeight = '0';
            });

            item.classList.add('open');

            if (accordionArrow !== null)
                accordionArrow.setAttribute('fill', '#D60026');

            accordionAnswer.style.maxHeight = accordionAnswer.scrollHeight + 'px';
        }
    });
});