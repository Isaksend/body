<?php
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;

    require '../../vendor/autoload.php';
    require '../../helpers/email.php';
    require '../../config/configs.php';

    $mail = new PHPMailer(true);

    $username = htmlspecialchars($_POST['username']);
    $phone = htmlspecialchars($_POST['phone']);
    $message = "Новый заказ!<br><br>{$_POST['message']}<br>Контакты:<br>Номер: {$phone}<br>Имя: {$username}";
    // Тут будет добавляться название услуги
    $subject = 'Заказ номер: #' . rand(1, 999);

    try {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (empty($_POST)) {
                $json = array('status' => 'error', 'message' => 'В запросе POST ничего нет.');
            }
            else if (empty($message) or empty($phone) or empty($username)) {
                $json = array('status' => 'error', 'message' => 'Поля пусты.');
            }
            else {
                $response = send_message($mail, $message, $subject);

                if ($response)
                    $json = array('status' => 'ok', 'message' => 'Успешная отправка.');
                else
                    $json = array('status' => 'error', 'message' => 'Не удалось отправить сообщение.');
            }

            echo json_encode($json,  JSON_UNESCAPED_UNICODE);
        }
        else {
            $json = array('status' => 'error', 'message' => 'POST запрос не был отправлен.');
            echo json_encode($json,  JSON_UNESCAPED_UNICODE);
        }
    } catch (Exception $e) {
        $json = array('status' => 'error', 'message' => 'Неизвестная ошибка ' . $mail->ErrorInfo, 'error_message' => $e->getMessage());
        json_encode($json,  JSON_UNESCAPED_UNICODE);
    }
?>