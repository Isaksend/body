<?php

    use libraries\PHPMailer\PHPMailer\SMTP;

    function send_message($mail, $message, $subject)
    {
        global $mConfig;

        //$mail->SMTPDebug = SMTP::DEBUG_SERVER;
        $mail->isSMTP();
        $mail->CharSet = 'UTF-8';
        $mail->Host = $mConfig['smtp'];
        $mail->SMTPAuth = true;
        $mail->Username = $mConfig['mail_username'];
        $mail->Password = $mConfig['mail_password'];
        $mail->Port = $mConfig['port'];
        $mail->setFrom($mConfig['mail_username'], $mConfig['name_user']);
        $mail->addAddress($mConfig['to_mail'], "");

        $mail->SMTPSecure = $mConfig['smtp_secure'];
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $message;

        if ($mail->send()) return true;
        else return false;
    }
