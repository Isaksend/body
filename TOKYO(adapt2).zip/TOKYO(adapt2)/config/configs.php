<?php

    // Конфигурация email tokyo-krasnodar@yandex.ru
    $mConfig = [
        'mail_username' => 'info@jungfranco.ru',
        'mail_password' => 'btqzwv1sgj0MdypC23UD',
        'to_mail' => 'tokyo-krasnodar@yandex.ru',
        'name_user' => 'TOKIO: SPA салон',
        'smtp' => 'smtp.mail.ru',
        'port' => 465,
        'smtp_secure' => 'ssl'
    ];

    // Конфигурация капчи
    $captcha = [
      'captcha_url' => '',
      'captcha_key' => ''
    ];
